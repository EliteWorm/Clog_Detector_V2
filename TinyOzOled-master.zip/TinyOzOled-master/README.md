# TinyOzOled
OzOLED library using TinyWireM library for Attiny processors

This Library is  used in Battery Tester project ( https://youtu.be/mKPKQm0uPBQ )
